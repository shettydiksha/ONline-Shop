package com.lti.service;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Service;

import com.lti.dao.RetailerDao;
import com.lti.dto.RetailerDTO;
import com.lti.entity.Retailer;

@Service
public class RetailerService {
	@Autowired
	private RetailerDao retailerDao;

	public void add(RetailerDTO retailerDTO) {

		Retailer retailer = new Retailer();
		retailer.setCategoryname(retailerDTO.getCategoryname());
		retailer.setProductname(retailerDTO.getProductname());
		retailer.setPrice(retailerDTO.getPrice());
		retailer.setStocknumber(retailerDTO.getStocknumber());

		//ApplicationContext apx = new ClassPathXmlApplicationContext("src/main/webapp/WEB-INF/spring-config2.xml");
		 
		//retailerDao = (RetailerDao) apx.getBean("retailerDao");
		retailerDao.add(retailer);
	}

}
