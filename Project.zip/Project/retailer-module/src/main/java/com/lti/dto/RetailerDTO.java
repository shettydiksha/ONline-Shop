package com.lti.dto;

public class RetailerDTO {

	private String categoryname;
	private String productname;
	private int stocknumber;
	private int price;
	//================
	/*private String url;
public String getUrl() {
	return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}*/

	//===================
	public String getCategoryname() {
		return categoryname;
	}

	public void setCategoryname(String categoryname) {
		this.categoryname = categoryname;
	}

	public String getProductname() {
		return productname;
	}

	public void setProductname(String productname) {
		this.productname = productname;
	}

	public int getStocknumber() {
		return stocknumber;
	}

	public void setStocknumber(int stocknumber) {
		this.stocknumber = stocknumber;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

}
