package com.lti.controller;



import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.commons.CommonsMultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.lti.dto.RetailerDTO;
import com.lti.service.RetailerService;



//@SessionAttributes("message")
@Controller
public class RetailerController {
	 private static final String UPLOAD_DIRECTORY ="/images";  
	@Autowired
	private RetailerService retailerService;
	
	@RequestMapping(path = "/RetailerDisplay")
	public String hello(RetailerDTO retailerDTO) {
		retailerService.add(retailerDTO);
		//=========================================================
		
		
		//========================================================
		// model.put("message", "Welcome Retailer");
		return "redirect:/RetailerWelcome.jsp";
	}
	
	}
